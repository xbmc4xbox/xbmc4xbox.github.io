script.module.requests.lite
======================

Python requests library packed for XBMC.

See https://github.com/requests/requests
