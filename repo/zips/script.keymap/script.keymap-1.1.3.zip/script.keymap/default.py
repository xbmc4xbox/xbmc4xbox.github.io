import resources.lib.keymap as keymap

if __name__ == "__main__":
    keymap.main()
