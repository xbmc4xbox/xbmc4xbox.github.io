# webinterface.project.mayhem3 addon for XBMC

This is a [XBMC](https://xbmc.tv) web interface addon.

[![License: GPL-2.0-or-later](https://img.shields.io/badge/License-GPL%20v2+-blue.svg)](LICENSE.md)

![screenshot](https://raw.githubusercontent.com/xbmc4xbox/webinterface.project.mayhem3/refs/heads/master/resources/screenshot-01.png)
