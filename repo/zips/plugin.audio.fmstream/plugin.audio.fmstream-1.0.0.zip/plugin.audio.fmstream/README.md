# Radio for Original Xbox
Brand new Radio addon for XBMC4Xbox! You can now enjoy listening over 30k stations from all around the world on Original Xbox! Big thanks to [FMStream.org](http://fmstream.org) for allowing me to use their API.

## Support
<a href="https://www.buymeacoffee.com/antonic901" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>

## Info
This is addon for XBMC4Xbox 4.0+ that allows streaming of Radio stations on Original Xbox. It's using [FMStream.org](http://fmstream.org) API to fetch streams.

## How to install
This addon can be installed from [official](https://github.com/xbmc4xbox/xbmc4xbox.github.io) XBMC repository.
